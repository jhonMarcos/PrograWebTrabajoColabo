package pe.edu.upc.yachachikuy.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.yachachikuy.entities.Curso;
import pe.edu.upc.yachachikuy.repositories.ICursoRepository;
import pe.edu.upc.yachachikuy.serviceinterface.ICursoService;

@Service
public class CursoServiceImpl implements ICursoService {

	@Autowired
	private ICursoRepository cursoRepository;

	@Override
	public void insert(Curso curso) {
		// TODO Auto-generated method stub
		cursoRepository.save(curso);
	}

	@Override
	public List<Curso> list() {
		// TODO Auto-generated method stub
		return cursoRepository.findAll();
	}

	@Override
	public void delete(int C_Curso) {
		// TODO Auto-generated method stub
		cursoRepository.deleteById(C_Curso);
	}

	@Override
	public Optional<Curso> listId(int C_Curso) {
		// TODO Auto-generated method stub
		return cursoRepository.findById(C_Curso);
	}

	@Override
	public void update(Curso curso) {
		// TODO Auto-generated method stub
		cursoRepository.save(curso);
	}

}
