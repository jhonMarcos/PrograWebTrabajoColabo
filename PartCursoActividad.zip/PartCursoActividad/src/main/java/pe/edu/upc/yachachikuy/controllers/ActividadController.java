package pe.edu.upc.yachachikuy.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.yachachikuy.entities.Actividad;
import pe.edu.upc.yachachikuy.serviceinterface.IActividadService;
import pe.edu.upc.yachachikuy.serviceinterface.ICursoService;

@Controller
@RequestMapping("/aactividad")
public class ActividadController {

	@Autowired
	private ICursoService uService;

	@Autowired
	private IActividadService actividadService;

	@GetMapping("/new")
	public String newActividad(Model model) {
		model.addAttribute("a", new Actividad());
		model.addAttribute("listaCursos", uService.list());
		return "actividad/frmRegistro";
	}

	@PostMapping("/save")
	public String saveActividad(@Valid Actividad ac, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "actividad/frmRegistro";
		} else {
			actividadService.insert(ac);
			model.addAttribute("mensaje", "Se registro correctamente");
			return "redirect:/aactividad/list";
		}
	}

	@GetMapping("/list")
	public String listActividad(Model model) {
		try {
			model.addAttribute("listaActividad", actividadService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "/actividad/frmLista";
	}

	@RequestMapping("/delete")
	public String deleteActividad(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				actividadService.delete(id);
				model.put("listaActividad", actividadService.list());
			}
		} catch (Exception e) {
			model.put("error", e.getMessage());
		}

		return "actividad/frmLista";
	}

	@RequestMapping("/goupdate/{id}")
	public String goUpdateActividad(@PathVariable int id, Model model) {

		Optional<Actividad> objUs = actividadService.listId(id);
		model.addAttribute("ac", objUs.get());
		model.addAttribute("listaCursos", uService.list());
		return "actividad/frmActualiza";
	}

	@PostMapping("/update")
	public String updateProfesor(Actividad a) {
		actividadService.update(a);
		return "redirect:/aactividad/list";
	}

}
