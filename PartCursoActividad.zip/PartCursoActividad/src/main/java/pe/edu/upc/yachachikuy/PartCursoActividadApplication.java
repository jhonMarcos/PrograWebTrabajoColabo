package pe.edu.upc.yachachikuy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartCursoActividadApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartCursoActividadApplication.class, args);
	}

}
