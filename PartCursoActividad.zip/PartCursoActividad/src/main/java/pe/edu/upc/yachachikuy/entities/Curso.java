package pe.edu.upc.yachachikuy.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Curso")
public class Curso {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idCurso;

	@Column(name = "nomCurso", nullable = false)
	private int nomCurso;

	@Column(name = "profesorUsuario", nullable = false)
	private int profesorUsuario;

	public Curso() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Curso(int idCurso, int nomCurso, int profesorUsuario) {
		super();
		this.idCurso = idCurso;
		this.nomCurso = nomCurso;
		this.profesorUsuario = profesorUsuario;
	}

	public int getIdCurso() {
		return idCurso;
	}

	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}

	public int getNomCurso() {
		return nomCurso;
	}

	public void setNomCurso(int nomCurso) {
		this.nomCurso = nomCurso;
	}

	public int getProfesorUsuario() {
		return profesorUsuario;
	}

	public void setProfesorUsuario(int profesorUsuario) {
		this.profesorUsuario = profesorUsuario;
	}

	

}
