package pe.edu.upc.yachachikuy.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Curso")
public class Curso {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int C_Curso;

	@Column(name = "N_Curso", nullable = false)
	private int N_Curso;

	@Column(name = "Profesor_C_Usuario", nullable = false)
	private int Profesor_C_Usuario;

	public Curso() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Curso(int c_Curso, int n_Curso, int profesor_C_Usuario) {
		super();
		C_Curso = c_Curso;
		N_Curso = n_Curso;
		Profesor_C_Usuario = profesor_C_Usuario;
	}

	public int getC_Curso() {
		return C_Curso;
	}

	public void setC_Curso(int c_Curso) {
		C_Curso = c_Curso;
	}

	public int getN_Curso() {
		return N_Curso;
	}

	public void setN_Curso(int n_Curso) {
		N_Curso = n_Curso;
	}

	public int getProfesor_C_Usuario() {
		return Profesor_C_Usuario;
	}

	public void setProfesor_C_Usuario(int profesor_C_Usuario) {
		Profesor_C_Usuario = profesor_C_Usuario;
	}

}
