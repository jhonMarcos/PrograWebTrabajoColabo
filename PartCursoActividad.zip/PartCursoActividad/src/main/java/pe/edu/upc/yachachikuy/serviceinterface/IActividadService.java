package pe.edu.upc.yachachikuy.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.yachachikuy.entities.Actividad;

public interface IActividadService {

	public void insert(Actividad actividad);

	List<Actividad> list();

	public void delete(int C_Actividad);

	Optional<Actividad> listId(int C_Actividad);

	public void update(Actividad actividad);

}
