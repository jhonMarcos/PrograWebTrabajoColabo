package pe.edu.upc.yachachikuy.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.yachachikuy.entities.Actividad;

public interface IActividadService {

	public void insert(Actividad actividad);

	List<Actividad> list();

	public void delete(int idActividad);

	Optional<Actividad> listId(int idActividad);

	public void update(Actividad actividad);

}
