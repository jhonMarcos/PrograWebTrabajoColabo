package pe.edu.upc.yachachikuy.serviceinterface;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.yachachikuy.entities.Curso;

public interface ICursoService {

	public void insert(Curso curso);

	List<Curso> list();

	public void delete(int C_Curso);

	Optional<Curso> listId(int C_Curso);

	public void update(Curso curso);

}
