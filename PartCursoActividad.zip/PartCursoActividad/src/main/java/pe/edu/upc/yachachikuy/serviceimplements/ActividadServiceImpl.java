package pe.edu.upc.yachachikuy.serviceimplements;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.yachachikuy.entities.Actividad;
import pe.edu.upc.yachachikuy.repositories.IActividadRepository;
import pe.edu.upc.yachachikuy.serviceinterface.IActividadService;

@Service
public class ActividadServiceImpl implements IActividadService {

	@Autowired
	private IActividadRepository actividadRepository;

	@Override
	public void insert(Actividad actividad) {
		// TODO Auto-generated method stub
		actividadRepository.save(actividad);
	}

	@Override
	public List<Actividad> list() {
		// TODO Auto-generated method stub
		return actividadRepository.findAll();
	}

	@Override
	public void delete(int idActividad) {
		// TODO Auto-generated method stub
		actividadRepository.deleteById(idActividad);
	}

	@Override
	public Optional<Actividad> listId(int idActividad) {
		// TODO Auto-generated method stub
		return actividadRepository.findById(idActividad);
	}

	@Override
	public void update(Actividad actividad) {
		// TODO Auto-generated method stub
		actividadRepository.save(actividad);
	}

}
