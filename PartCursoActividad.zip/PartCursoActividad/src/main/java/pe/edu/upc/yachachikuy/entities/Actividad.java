package pe.edu.upc.yachachikuy.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name = "Actividad")
public class Actividad {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idActividad;

	@Max(20)
	@Min(0)
	private int numNota;

	@Column(name = "numActividad", length = 48, nullable = false)
	private String nomActividad;

	@Column(name = "numActividades", nullable = false)
	private int numActividades;

	@Column(name = "porcCompletado", nullable = false)
	private int porcCompletado;

	@Column(name = "fEstado", length = 48, nullable = false)
	private String fEstado;

	@ManyToOne
	@JoinColumn(name = "idCurso")
	private Curso curso;

	public Actividad() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Actividad(int idActividad, @Max(20) @Min(0) int numNota, String nomActividad, int numActividades,
			int porcCompletado, String fEstado, Curso curso) {
		super();
		this.idActividad = idActividad;
		this.numNota = numNota;
		this.nomActividad = nomActividad;
		this.numActividades = numActividades;
		this.porcCompletado = porcCompletado;
		this.fEstado = fEstado;
		this.curso = curso;
	}

	public int getIdActividad() {
		return idActividad;
	}

	public void setIdActividad(int idActividad) {
		this.idActividad = idActividad;
	}

	public int getNumNota() {
		return numNota;
	}

	public void setNumNota(int numNota) {
		this.numNota = numNota;
	}

	public String getNomActividad() {
		return nomActividad;
	}

	public void setNomActividad(String nomActividad) {
		this.nomActividad = nomActividad;
	}

	public int getNumActividades() {
		return numActividades;
	}

	public void setNumActividades(int numActividades) {
		this.numActividades = numActividades;
	}

	public int getPorcCompletado() {
		return porcCompletado;
	}

	public void setPorcCompletado(int porcCompletado) {
		this.porcCompletado = porcCompletado;
	}

	public String getfEstado() {
		return fEstado;
	}

	public void setfEstado(String fEstado) {
		this.fEstado = fEstado;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

}
