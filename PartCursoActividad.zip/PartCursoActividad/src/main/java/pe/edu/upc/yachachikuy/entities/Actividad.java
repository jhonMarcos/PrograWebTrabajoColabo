package pe.edu.upc.yachachikuy.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name = "Actividad")
public class Actividad {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int C_Actividad;

	@Column(name = "C_Curso", nullable = false)
	private int C_Curso;

	@Max(20)
	@Min(0)
	private int Num_Nota;

	@Column(name = "N_Actividad", length = 48, nullable = false)
	private String N_Actividad;

	@Column(name = "Num_Actividades", nullable = false)
	private int Num_Actividades;

	@Column(name = "Por_Completado", nullable = false)
	private int Por_Completado;

	@Column(name = "F_Estado", length = 48, nullable = false)
	private String F_Estado;

	@ManyToOne
	@JoinColumn(name = "C_Curso")
	private Curso curso;

	public Actividad() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Actividad(int c_Actividad, int c_Curso, int num_Nota, String n_Actividad, int num_Actividades,
			int por_Completado, String f_Estado) {
		super();
		C_Actividad = c_Actividad;
		C_Curso = c_Curso;
		Num_Nota = num_Nota;
		N_Actividad = n_Actividad;
		Num_Actividades = num_Actividades;
		Por_Completado = por_Completado;
		F_Estado = f_Estado;
	}

	public int getC_Actividad() {
		return C_Actividad;
	}

	public void setC_Actividad(int c_Actividad) {
		C_Actividad = c_Actividad;
	}

	public int getC_Curso() {
		return C_Curso;
	}

	public void setC_Curso(int c_Curso) {
		C_Curso = c_Curso;
	}

	public int getNum_Nota() {
		return Num_Nota;
	}

	public void setNum_Nota(int num_Nota) {
		Num_Nota = num_Nota;
	}

	public String getN_Actividad() {
		return N_Actividad;
	}

	public void setN_Actividad(String n_Actividad) {
		N_Actividad = n_Actividad;
	}

	public int getNum_Actividades() {
		return Num_Actividades;
	}

	public void setNum_Actividades(int num_Actividades) {
		Num_Actividades = num_Actividades;
	}

	public int getPor_Completado() {
		return Por_Completado;
	}

	public void setPor_Completado(int por_Completado) {
		Por_Completado = por_Completado;
	}

	public String getF_Estado() {
		return F_Estado;
	}

	public void setF_Estado(String f_Estado) {
		F_Estado = f_Estado;
	}

}
