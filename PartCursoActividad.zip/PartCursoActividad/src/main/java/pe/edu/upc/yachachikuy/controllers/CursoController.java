package pe.edu.upc.yachachikuy.controllers;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.yachachikuy.entities.Curso;
import pe.edu.upc.yachachikuy.serviceinterface.ICursoService;

@Controller
@RequestMapping("/ccursos")
public class CursoController {

	@Autowired
	private ICursoService cursoService;

	@GetMapping("/new")
	public String newCurso(Model model) {
		model.addAttribute("u", new Curso());
		return "curso/frmRegistro";
	}

	@PostMapping("/save")
	public String saveCurso(@Valid Curso cu, BindingResult binRes, Model model) {
		if (binRes.hasErrors()) {
			return "curso/frmRegistro";
		} else {
			cursoService.insert(cu);
			model.addAttribute("mensaje", "Se registro correctamente");
			return "redirect:/cccursos/list";
		}
	}

	@GetMapping("/list")
	public String listCurso(Model model) {
		try {
			model.addAttribute("listaCursos", cursoService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "/curso/frmLista";
	}

	@RequestMapping("/delete")
	public String deleteCurso(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				cursoService.delete(id);
				model.put("listaUsuarios", cursoService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}

		return "curso/frmLista";
	}

	@RequestMapping("/goupdate/{id}")
	public String goUpdateCurso(@PathVariable int id, Model model) {

		Optional<Curso> objUs = cursoService.listId(id);
		model.addAttribute("cu", objUs.get());
		return "curso/frmActualiza";
	}

	@PostMapping("/update")
	public String updateCurso(Curso c) {
		cursoService.update(c);
		return "redirect:/ccursos/list";
	}

}
